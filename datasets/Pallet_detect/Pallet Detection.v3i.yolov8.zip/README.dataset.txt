# Pallet Detection > 2025-05-08 3:41am
https://universe.roboflow.com/abhinav-cnqq3/pallet-detection-1kv3d

Provided by a Roboflow user
License: CC BY 4.0

